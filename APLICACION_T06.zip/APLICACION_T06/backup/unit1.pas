
unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs,
  StdCtrls, uTexto;

type

  { TForm1 }

  TForm1 = class(TForm)
    BtnContarPalabras: TButton;
    BtnContarParrafos: TButton;
    BtnBuscar: TButton;
    BtnReemplazar: TButton;
    BtnMezclar: TButton;
    EditBuscar: TEdit;
    EditReemplazo: TEdit;
    MemoTexto: TMemo;
    OpenDialog1: TOpenDialog;
    SaveDialog1: TSaveDialog;

    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);

    procedure BtnContarPalabrasClick(Sender: TObject);
    procedure BtnContarParrafosClick(Sender: TObject);
    procedure BtnBuscarClick(Sender: TObject);
    procedure BtnReemplazarClick(Sender: TObject);
    procedure BtnMezclarClick(Sender: TObject);

  private
    MiTexto: TTexto;

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ Crear el objeto }

procedure TForm1.FormCreate(Sender: TObject);
begin
  MiTexto := TTexto.Create;
end;

{ Liberar el objeto }

procedure TForm1.FormDestroy(Sender: TObject);
begin
  MiTexto.Free;
end;

{ 1. Contar palabras }

procedure TForm1.BtnContarPalabrasClick(Sender: TObject);
var
  Cantidad: Integer;
begin
  MiTexto.CargarTexto(MemoTexto.Text);

  Cantidad := MiTexto.ContarPalabras;

  ShowMessage('Cantidad de palabras: ' + IntToStr(Cantidad));
end;

{ 2. Contar parrafos }

procedure TForm1.BtnContarParrafosClick(Sender: TObject);
var
  Cantidad: Integer;
begin
  MiTexto.CargarTexto(MemoTexto.Text);

  Cantidad := MiTexto.ContarParrafos;

  ShowMessage('Cantidad de parrafos: ' + IntToStr(Cantidad));
end;

{ 3. Buscar palabra }

procedure TForm1.BtnBuscarClick(Sender: TObject);
var
  Cantidad: Integer;
  Palabra: string;
begin
  Palabra := Trim(EditBuscar.Text);

  if Palabra = '' then
  begin
    ShowMessage('Ingrese la palabra que desea buscar');
    Exit;
  end;

  MiTexto.CargarTexto(MemoTexto.Text);

  Cantidad := MiTexto.BuscarPalabra(Palabra);

  if Cantidad > 0 then
    ShowMessage('La palabra "' + Palabra + '" aparece ' +
                IntToStr(Cantidad) + ' veces.')
  else
    ShowMessage('No se encontro la palabra.');
end;

{ 4. Reemplazar palabra }

procedure TForm1.BtnReemplazarClick(Sender: TObject);
var
  Buscar, Reemplazo: string;
begin
  Buscar := Trim(EditBuscar.Text);
  Reemplazo := EditReemplazo.Text;

  if Buscar = '' then
  begin
    ShowMessage('Ingrese la palabra que desea reemplazar');
    Exit;
  end;

  MiTexto.CargarTexto(MemoTexto.Text);

  MiTexto.ReemplazarPalabra(Buscar, Reemplazo);

  MemoTexto.Text := MiTexto.Contenido.Text;

  ShowMessage('Reemplazo realizado correctamente.');
end;

{ 5. Mezclar dos archivos }

procedure TForm1.BtnMezclarClick(Sender: TObject);
var
  Archivo1, Archivo2, Resultado: TStringList;
begin
  Archivo1 := TStringList.Create;
  Archivo2 := TStringList.Create;
  Resultado := TStringList.Create;

  try
    OpenDialog1.Title := 'Seleccionar el primer archivo';
    OpenDialog1.Filter := 'Archivos de texto (*.txt)|*.txt';

    if not OpenDialog1.Execute then
      Exit;

    Archivo1.LoadFromFile(OpenDialog1.FileName);

    OpenDialog1.Title := 'Seleccionar el segundo archivo';

    if not OpenDialog1.Execute then
      Exit;

    Archivo2.LoadFromFile(OpenDialog1.FileName);

    Resultado.AddStrings(Archivo1);
    Resultado.AddStrings(Archivo2);

    SaveDialog1.Title := 'Guardar archivo mezclado';
    SaveDialog1.Filter := 'Archivos de texto (*.txt)|*.txt';
    SaveDialog1.DefaultExt := 'txt';
    SaveDialog1.FileName := 'texto_mezclado.txt';

    if SaveDialog1.Execute then
    begin
      Resultado.SaveToFile(SaveDialog1.FileName);
      ShowMessage('Los archivos se mezclaron correctamente.');
    end;

  finally
    Archivo1.Free;
    Archivo2.Free;
    Resultado.Free;
  end;
end;

end.

