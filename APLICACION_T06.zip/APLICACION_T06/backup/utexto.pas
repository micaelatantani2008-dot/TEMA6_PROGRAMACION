unit uTexto;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils;

type
  TTexto = class
  private
    FContenido: TStringList;
  public
    constructor Create;
    destructor Destroy; override;

    procedure CargarTexto(Contenido: string);
    function ContarPalabras: Integer;
    function ContarParrafos: Integer;
    function BuscarPalabra(Palabra: string): Integer;
    procedure ReemplazarPalabra(Buscar, Reemplazo: string);

    property Contenido: TStringList read FContenido;
  end;

implementation

constructor TTexto.Create;
begin
  FContenido := TStringList.Create;
end;

destructor TTexto.Destroy;
begin
  FContenido.Free;
  inherited Destroy;
end;

procedure TTexto.CargarTexto(Contenido: string);
begin
  FContenido.Text := Contenido;
end;

function TTexto.ContarPalabras: Integer;
var
  i, j: Integer;
  Linea: string;
  DentroPalabra: Boolean;
begin
  Result := 0;

  for i := 0 to FContenido.Count - 1 do
  begin
    Linea := Trim(FContenido[i]);
    DentroPalabra := False;

    for j := 1 to Length(Linea) do
    begin
      if Linea[j] > ' ' then
      begin
        if not DentroPalabra then
        begin
          Inc(Result);
          DentroPalabra := True;
        end;
      end
      else
        DentroPalabra := False;
    end;
  end;
end;

function TTexto.ContarParrafos: Integer;
var
  i: Integer;
  HayTexto: Boolean;
begin
  Result := 0;
  HayTexto := False;

  for i := 0 to FContenido.Count - 1 do
  begin
    if Trim(FContenido[i]) <> '' then
    begin
      if not HayTexto then
      begin
        Inc(Result);
        HayTexto := True;
      end;
    end
    else
      HayTexto := False;
  end;
end;

function TTexto.BuscarPalabra(Palabra: string): Integer;
var
  TextoCompleto: string;
  Posicion: Integer;
begin
  TextoCompleto := FContenido.Text;
  Posicion := 1;
  Result := 0;

  while Posicion <= Length(TextoCompleto) do
  begin
    Posicion := Pos(LowerCase(Palabra),
                    LowerCase(Copy(TextoCompleto, Posicion, Length(TextoCompleto))));

    if Posicion = 0 then
      Break;

    Inc(Result);
    Posicion := Posicion + Length(Palabra);
  end;
end;

procedure TTexto.ReemplazarPalabra(Buscar, Reemplazo: string);
var
  i: Integer;
begin
  for i := 0 to FContenido.Count - 1 do
    FContenido[i] := StringReplace(FContenido[i], Buscar, Reemplazo,
                                   [rfReplaceAll, rfIgnoreCase]);
end;

end.

